https://en.wikipedia.org/wiki/Cisco_IOS
http://ctf.forgottensec.com/wiki/index.php?title=Main_Page
https://github.com/jordanpotti/ccdc
https://www.scriptjunkie.us/2014/03/ccdc-and-ctfs-addressing-the-criticisms/
https://alexlevinson.wordpress.com/2017/05/09/know-your-opponent-my-ccdc-toolbox/

https://github.com/redactlabs/ccdc/tree/master/Services
https://sites.google.com/site/howtoccdc/scoring/injects
https://github.com/redactlabs/ccdc/blob/master/wrccdc-injects-2011-invitational.pdf

https://sites.google.com/site/howtoccdc/tips
https://www.trustwave.com/en-us/resources/blogs/spiderlabs-blog/web-application-defenders-cookbook-ccdc-blue-team-cheatsheet/
https://cyb3rs3c.blogspot.com/2011/03/mid-atlantic-collegiate-cyber-defense.html
https://www.christophertruncer.com/red-teaming-a-ccdc-practice-event/
https://blog.cobaltstrike.com/2015/04/17/so-you-won-a-regional-and-youre-headed-to-national-ccdc/
https://alexlevinson.wordpress.com/2015/04/27/ccdc-2015-debrief-red-team-identity/
https://net-force.net/2014-western-regional-collegiate-cyber-defense-competition-wrccdc-analysis/1317/

### Repos

https://github.com/CSUSB-CCDC/CCDC-Notes

https://github.com/CSUSB-CCDC/AwesomeLinuxLearning

https://github.com/mubix/howtowinccdc

### Reddit

https://www.reddit.com/r/netsec/comments/oyr7l/im_going_to_be_participating_in_the_national/

https://www.reddit.com/r/cybersecurity/comments/22q9qr/preparing_for_a_cyberdefense_competition/
