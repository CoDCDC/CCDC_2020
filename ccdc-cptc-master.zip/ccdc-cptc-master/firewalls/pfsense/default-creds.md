# Defaults

## Web UI

```
Username: admin
Password: pfsense
```
