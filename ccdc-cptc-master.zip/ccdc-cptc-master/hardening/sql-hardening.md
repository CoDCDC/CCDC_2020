# SQL Hardening

- https://medium.com/linode-cube/5-essential-steps-to-hardening-your-mysql-database-591e477bbbd7
- https://www.techrepublic.com/article/how-to-harden-mysql-security-with-a-single-command/
- https://www.tecklyfe.com/harden-mysql-server/

- Set strong passwords and change default passwords
  - `sudo mysqladmin password`
  - Unfortunately, MySQL runs background tasks as that root user. These tasks will break once you set a password, unless you take the additional step of hard-coding the password into the /root/.my.cnf file:
  ```
  [mysqladmin]
  user = root
  password = yourpassword
  ```
  Make sure to restrict access to that file
  ```
  $ sudo chown root:root /root/.my.cnf
  $ sudo chmod 0600 /root/.my.cnf
  ```
- Remove unnecessary users
  - Remove anonymous user
  ```sql
  > drop user “”@”localhost”;
  > flush privileges;
  ```
- Only grant access to the needed databases
  ```sql
  > grant all privileges on mydb.* to someuser@”localhost” identified by ‘astrongpassword’;
  > flush privileges;
  ```
  - You can also grant specific privileges (select, drop, delete, etc.)
- Enable TLS
  - Once you have valid certs, add this to my.cnf
  ```
  [mysqld]
  ssl-ca=/path/to/ca.crt
  ssl-cert=/path/to/server.crt
  ssl-key=/path/to/server.key
  ```
  - Also, make sure the SSL cipher suites are strong ones
