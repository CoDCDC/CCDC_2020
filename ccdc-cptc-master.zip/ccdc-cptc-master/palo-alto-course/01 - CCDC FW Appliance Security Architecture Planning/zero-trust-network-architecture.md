# Zero Trust Network Architecture

No trust within the network, it's not needed

### 3 Main Concepts

- All resources must be accessed in a secure manner regardless of location

- Enforce access control in a granular manner

- Inspect and log all traffic

### Segmentation Gateway

Combine Access Control, Firewall, Packet Forwarding, etc. into one appliance

MCAP - Micro core and perimeter

Centralized management infrastructure

Modular


