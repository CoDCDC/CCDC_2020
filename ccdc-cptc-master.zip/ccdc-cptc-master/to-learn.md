TLS

SSL

Trunk

DHCP

Gateway

VLAN

IP Tables

https://en.wikipedia.org/wiki/UDP_Unicorn
https://en.wikipedia.org/wiki/Low_Orbit_Ion_Cannon
https://en.wikipedia.org/wiki/UDP_flood_attack
https://en.wikipedia.org/wiki/Smurf_attack
https://en.wikipedia.org/wiki/SYN_flood
https://en.wikipedia.org/wiki/Internet_Control_Message_Protocol
https://en.wikipedia.org/wiki/Directory_service
