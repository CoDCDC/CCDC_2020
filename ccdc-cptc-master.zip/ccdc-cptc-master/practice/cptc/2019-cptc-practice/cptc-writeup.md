# Linux Box - 192.169.1.127

## Portscan - `nmap -n 192.168.1.127`

Open ports:
```
22
80
443
8080
50000
```

## Port 8080 - Jenkins
### Credentials
```
admin
admin
```

### Reverse Shell
Using a reverse shell from [here](http://pentestmonkey.net/cheat-sheet/shells/reverse-shell-cheat-sheet), I set up a reverse shell in the start-up script in a Jenkins Build called `exploit`. That reverse shell sent the responses to my IP address at port 75, and I ran `nc -lvp 75` on my local machine to listen.

The reverse shell dropped me into `var/jenkins_home` running `/bin/sh`. The contents of that directory are listed below.

The machine was running Ubuntu Linux 4.15.0-58-generic.

![](jenkins.png)

## Remediation

Close port `8080` to public access. Idiot.
