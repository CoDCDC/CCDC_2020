sudo apt-get install bettercap bloodhound burpsuite crackmapexec dnsutils enum4linux hashcat hydra john metasploit-framework nikto nmap openvas responder ridenum smbclient sqlmap
# dnsutils - dig
