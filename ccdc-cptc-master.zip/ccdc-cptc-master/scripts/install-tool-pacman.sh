sudo pacman -S bettercap dnsutils hashcat hydra john metasploit nikto nmap openvas smbclient sqlmap
# dnsutils - dig

yay -S burpsuite crackmapexec enum4linux responder
